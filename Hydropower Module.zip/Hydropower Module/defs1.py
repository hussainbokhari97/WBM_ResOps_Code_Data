from pyomo.environ import ConcreteModel, Objective, Expression, value, Var, Param, Constraint, ConstraintList, Set, assert_optimal_termination, \
check_optimal_termination, Block, log, log10, SolverFactory, units as pyunits
import pyomo.util.infeasible as infeas

from pyomo.environ import Var, Expression, NonNegativeReals, Block, ConcreteModel, Constraint, Objective, SolverFactory, TransformationFactory, units as pyunits, value


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
#get_ipython().run_line_magic('matplotlib', 'inline')

from IPython.display import clear_output

from sklearn.metrics import r2_score

import itertools

import plotly.express as px 
import ast
import scipy
import warnings
warnings.filterwarnings("ignore")

from multiprocessing import Process
from multiprocessing import Pool

def nse(predictions, targets):
    return (1-(np.sum((targets-predictions)**2)/np.sum((targets-np.mean(targets))**2)))

def f1(x):
    return x*x

def clean_pnnl(df):
    df['month_number'] = np.array(1)
    df.month_number = np.where(df.month == 'Feb', 2, df.month_number)
    df.month_number = np.where(df.month == 'Mar', 3, df.month_number)
    df.month_number = np.where(df.month == 'Apr', 4, df.month_number)
    df.month_number = np.where(df.month == 'May', 5, df.month_number)
    df.month_number = np.where(df.month == 'Jun', 6, df.month_number)
    df.month_number = np.where(df.month == 'Jul', 7, df.month_number)
    df.month_number = np.where(df.month == 'Aug', 8, df.month_number)
    df.month_number = np.where(df.month == 'Sep', 9, df.month_number)
    df.month_number = np.where(df.month == 'Oct', 10, df.month_number)
    df.month_number = np.where(df.month == 'Nov', 11, df.month_number)
    df.month_number = np.where(df.month == 'Dec', 12, df.month_number)
    
    df['eia_yr_m'] = df.EIA_ID.astype(str) + '_' + df.year.astype(str) + '_' + df.month_number.astype(str)
    
    df['rec_gen'] = np.where(df.recommended_data == 'EIA-923', df.EIA_MWh, df.RectifHyd_MWh)
    
    d31 = [10, 12, 1, 3, 5, 7, 8]
    leap_years = [2000, 2004, 2008, 2012, 2016, 2020]
    
    df['days_in_month'] = np.where( df['month_number'].isin(d31), 31, 30)
    df['days_in_month'] = np.where(df.month_number == 2, 28, df.days_in_month)
    df['days_in_month'] = np.where( ((df['year'].isin(leap_years)) & (df.month_number == 2)), 29, df.days_in_month)
    
    df['m_y'] = df.month_number.astype(str) + '_' + df.year.astype(str)
    
    return df


def import_inputs(scenario_name):

    # import WBM results
    df_wbm = pd.read_csv(WBM RESULT OUTPUT FILE)
    print("done reading in file")
    # Import monthly generation from EIA, PNNL and WBM 
    # NOTE THAT YOU NEED TO SET EIA MWH TO WHATEVER METHOD YOU PREFER FOR MONTHLY GENERATION!


    #df = pd.read_csv('../wbm_EIA_join_2001_2020.csv') #WBM_EIA_HydroGen_join.csv')

    df_wbm = df_wbm.drop_duplicates()
    #df_wbm['month'] = pd.DatetimeIndex(df_wbm['Date']).month
    #df_wbm['year'] = pd.DatetimeIndex(df_wbm['Date']).year
    df = pd.DataFrame()
    df = df_wbm.groupby(["EIA ID", "year", "month"]).sum()[["InFlow (m3/s)", "Release (m3/s)", 
                                                                "Power (MW) - WBM", 'Storage (m3)', 'CH_CW']]
    
    
    
    df["WBM_MWh"] = df["Power (MW) - WBM"] * 24
    df['TotalInFlow_m3'] = df['InFlow (m3/s)'] #* 24*3600 #UNITS: now is total flow over time period
    df['TotalRelease_m3'] = df['Release (m3/s)'] #* 24*3600 #UNITS: now is total flow over time period
    df['Storage (m3)'] = df['Storage (m3)'] * 1e-6 #UNITS: 

    del df["Power (MW) - WBM"]; del df['InFlow (m3/s)']; del df['Release (m3/s)']
    df = df.reset_index()

    df = df.rename(columns={"EIA ID": "EIA_ID"})

    # add hoover dam
    df_hoover = df[df.EIA_ID == 154]
    df_hoover.EIA_ID = 8902
    df = pd.concat([df, df_hoover], ignore_index=True)
       
    df['eia_yr_m'] = df.EIA_ID.astype(int).astype(str) + '_' + df.year.astype(str) + '_' + df.month.astype(str)

    # add observed monthly generation
    df_pnnl = pd.read_csv("RectifHyd_v1.0.1.csv")
    df_pnnl = clean_pnnl(df_pnnl)
    
    gen_scenario = "rec"
    if gen_scenario == "rec":
        df['pnnl_gen'] = df.eia_yr_m.map(df_pnnl.groupby('eia_yr_m').sum()['rec_gen'])
    else:
        df['pnnl_gen'] = df.eia_yr_m.map(df_pnnl.groupby('eia_yr_m').sum()['EIA_MWh'])
    
    
    #df['days_in_month'] = df.eia_yr_m.map(df_pnnl.groupby('eia_yr_m').max()['days_in_month'])

    #cap max observed gen
    df['monthly_max_gen'] = df.CH_CW * 24
    df['pnnl_gen'] = np.where(df.monthly_max_gen > df.pnnl_gen, df.pnnl_gen, df.monthly_max_gen)

    df_hist = df.dropna()
    
    
    # CLEAN DATA
    df_hist = df_hist.dropna()
    df_hist = df_hist[df_hist.pnnl_gen > 0] # remove values that would distort the regression
    df_hist['season'] = np.where(df_hist.month == 3, 3, 1)
    df_hist['season'] = np.where(df_hist.month == 4, 3, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 5, 3, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 6, 4, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 7, 4, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 8, 4, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 9, 2, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 10, 2, df_hist['season'])
    df_hist['season'] = np.where(df_hist.month == 11, 2, df_hist['season'])                    
    #df_hist.season = df_hist.season * 1e9

    # apply max nameplate gen or not:
    #df_hist['WBM_MWh_capped'] = np.where((df_hist["Storage (m3)"] == 0) & (df_hist.WBM_MWh > df_hist.CH_CW * 24), df_hist.CH_CW * 24, df_hist.WBM_MWh)

    #df_hist = df_hist[[col for col in df_hist.columns if col != 'pnnl_gen'] + ['pnnl_gen']]

    df_hist_back_up = df_hist.copy(deep = True)
    
    
    return df_hist




def build_hydro_model(scenario_name, df_hist, eia, initial = False):
    
    
    print('CALCULATING:', scenario_name, eia, '----------')
       
    df_test = df_hist[df_hist.EIA_ID == eia]
    df_test['Storage'] = df_test["Storage (m3)"]
    df_test = df_test.reset_index()
    #df_test = df_test[((df_test.month >=4) & (df_test.month <=9))]
        
    release_adj = 10**-(len(str(int(df_test[df_test.EIA_ID == eia].TotalRelease_m3.max()))))
    storage_adj = 10**-(len(str(int(df_test[df_test.EIA_ID == eia].Storage.max()))))
    hydro_adj = 10**-(len(str(int(df_test[df_test.EIA_ID == eia].pnnl_gen.max()))))
#    inflow_adj = 10**-(len(str(int(df_test[df_test.EIA_ID == eia].TotalInFlow_m3.max()))))
#     print(df_test.TotalRelease_m3.max())
#     print(df_test.Storage.max())

    adj_dict = {}
    adj_dict['eia'] = eia
    adj_dict['release_adj'] = release_adj
    adj_dict['storage_adj'] = storage_adj
    adj_dict['hydro_adj'] = hydro_adj

    adj_df = pd.DataFrame(adj_dict.items()).T
    new_header = adj_df.iloc[0] #grab the first row for the header
    adj_df = adj_df[1:] #take the data less the header row
    adj_df.columns = new_header #set the header row as the df header
    
    df_test.TotalRelease_m3 = release_adj * df_test.TotalRelease_m3
    df_test.Storage = storage_adj * df_test.Storage 
    #df_test.TotalInFlow_m3 = inflow_adj * df_test.TotalInFlow_m3 
    
    #df_test.pnnl_gen = hydro_adj * df_test.pnnl_gen
#     print("AFTER")
#     print(df_test.TotalRelease_m3.max())
#     print(df_test.Storage.max())
    
    m = ConcreteModel()
    
    m.idx = Set(initialize=df_test.index)
    
    if initial == False:
    
        m.a = Var(initialize=1, bounds=(0, None))
        m.b = Var(initialize=1, bounds=(0, None))
        m.c = Var(initialize=1, bounds=(0, None))
        m.d = Var(initialize=1, bounds=(0.5, 3))
        m.e = Var(initialize=1, bounds=(0, None))
        m.f = Var(initialize=1, bounds=(0.5, 3))
        m.z = Var(initialize=1, bounds=(0,None))
        m.g = Var(initialize=1, bounds=(0,None))
    
    if initial == True:
        
        df_initial = pd.read_csv("final_combined_%s_nonlinear9.csv" % scenario_name)
        
        initial_a = df_initial[df_initial.EIA_ID == eia].t1_a.mean()
        initial_b = df_initial[df_initial.EIA_ID == eia].t1_b.mean()
        initial_c = df_initial[df_initial.EIA_ID == eia].t1_c.mean()
        initial_e = df_initial[df_initial.EIA_ID == eia].t1_e.mean()
        initial_d = df_initial[df_initial.EIA_ID == eia].t1_d.mean()
        initial_f = df_initial[df_initial.EIA_ID == eia].t1_f.mean()
        initial_z = df_initial[df_initial.EIA_ID == eia].t1_z.mean()
        
        if df_initial[df_initial.EIA_ID == eia].t1_d.mean() > 3: 
            initial_d = df_initial[df_initial.EIA_ID == eia].t1_d.mean() - 0.1
        else:
            initial_d = df_initial[df_initial.EIA_ID == eia].t1_d.mean() + 0.1

        if df_initial[df_initial.EIA_ID == eia].t1_f.mean() > 3: 
            initial_f = df_initial[df_initial.EIA_ID == eia].t1_f.mean() - 0.1
        else:
            initial_f = df_initial[df_initial.EIA_ID == eia].t1_f.mean() + 0.1            

        lba = initial_a/100
        lbb = initial_b/100
        lbc = initial_c/100
        lbd = initial_d/100
        lbe = initial_e/100
        lbf = initial_f/100
        lbz = initial_z/100
        
        uba = initial_a*100
        ubb = initial_b*100
        ubc = initial_c*100
        ubd = initial_d*100
        ube = initial_e*100
        ubf = initial_f*100
        ubz = initial_z*100
        
        m.a = Var(initialize=initial_a, bounds=(lba, uba))
        m.b = Var(initialize=initial_b, bounds=(lbb, ubb))
        m.c = Var(initialize=initial_c, bounds=(lbc, ubc))
        m.d = Var(initialize=initial_d, bounds=(0.5, 3))
        m.e = Var(initialize=initial_e, bounds=(lbe, ube))
        m.f = Var(initialize=initial_f, bounds=(0.5, 3))
        m.z = Var(initialize=initial_z, bounds=(lbz,ubz))
        
#         m.a = Var(initialize=initial_a, bounds=(0, None))
#         m.b = Var(initialize=initial_b, bounds=(0, None))
#         m.c = Var(initialize=initial_c, bounds=(0, None))
#         m.d = Var(initialize=initial_d, bounds=(0.5, 3))
#         m.e = Var(initialize=initial_e, bounds=(0, None))
#         m.f = Var(initialize=initial_f, bounds=(0.5,3))
#         m.z = Var(initialize=initial_z, bounds=(0,None))
        
        
    m.hydropower_estimate = Var(m.idx, 
                    initialize=df_test.pnnl_gen,
                    bounds=(0, df_test.CH_CW.max()*24*1.05),
                   doc='Modeled  hydro') # modeled release                    

    m.nse = Var(initialize=1, doc='Nash-Sutcliffe Coeff', bounds=(None, 1.01))   
    m.kge = Var(initialize=1, doc='KGE', bounds=(-3, 1.01)) 
    
    m.TotalRelease_m3 = Param(m.idx, initialize=df_test.TotalRelease_m3)
    m.Storage = Param(m.idx, initialize=df_test.Storage)
    m.season = Param(m.idx, initialize=df_test.season)
    m.TotalInFlow_m3 = Param(m.idx, initialize=df_test.TotalInFlow_m3)
    m.month = Param(m.idx, initialize=df_test.month)
    
    m.pnnl_gen = Param(m.idx, initialize=df_test.pnnl_gen)
   
    m.mean_pnnl_gen = np.mean(df_test.pnnl_gen)

    ### DEFINE CONSTRAINTS
    ## When defining a constraint over an index, it is easiest to make a "rule" function.
    ## The first argument to the function is the model (m), the next arguments are the index.
    ## In our case, we only have one index (the date)
    ## When defining these rule functions, it must return an inequality (i.e. ==, <=, >=)
    
    
    def hydropower_estimate(m, i):
        ## Note that this is just the function, not the Constraint itself.
        ## If you just had this function and not the Constraint below, it would have no effect.
        
        
        # for NSE INIT ACCESS AND NORESM -- if eia in [3050,6431]: # LINEAR TO NON1-> [3420, 3426, 4182, 265, 153, 759, 6172]: 
        if eia in []:
            #linear equation
            return m.hydropower_estimate[i] == (m.a * m.TotalRelease_m3[i] +
                                            m.b * m.TotalRelease_m3[i] * m.Storage[i] + 
                                            m.c * m.Storage[i])
        else:
            
            return m.hydropower_estimate[i] == (m.a * m.TotalRelease_m3[i] +
                                                m.b * m.TotalRelease_m3[i] * m.Storage[i] + 
                                                m.c * m.Storage[i] +
                                                m.e * m.TotalRelease_m3[i] ** m.d + 
                                                m.z * m.Storage[i] ** m.f) # +
                                                #m.g * m.TotalInFlow_m3[i])
        
    
#         # NEW -- + m.g * m.TotalInFlow_m3
    
    ## Here is the Constraint itself.
    ## When making an indexed Constraint, the first argument is the index (same as for Var or Param)
    ## Note that rather than the "expr" keyword, we use "rule" here, followed by the function we defined for this Constraint
    ## Pyomo automatically passes the model, and indexes (in that order) for the Constraint to the rule function
    
    # ----------------------------
    # ----------------------------
    
    m.hydropower_constr = Constraint(m.idx, rule=hydropower_estimate)
    
    m.hydropower_estimate_mean = sum((m.hydropower_estimate[i]) for i in m.idx)/len(df_test)
    
    m.nse_constr = Constraint(expr=m.nse == 1 - (sum((m.pnnl_gen[i] - m.hydropower_estimate[i]) ** 2 for i in m.idx) / 
                                                 sum((m.pnnl_gen[i] - m.mean_pnnl_gen) ** 2 for i in m.idx)))  
     
    # ----------------------------
    # ----------------------------

    m.mean_obs = m.mean_pnnl_gen

    m.mean_model = sum(m.hydropower_estimate[i] for i in m.idx)/len(m.hydropower_estimate)    
    
    m.corr_coeff = (sum((m.pnnl_gen[i] - m.mean_pnnl_gen) * 
                     (m.hydropower_estimate[i] - m.mean_model) for i in m.idx) / 
    ((sum((m.pnnl_gen[i] - m.mean_pnnl_gen) ** 2 for i in m.idx) * 
      sum((m.hydropower_estimate[i] - m.mean_model) ** 2 for i in m.idx)) ** 0.5))

    m.stdev_obs = (sum((m.pnnl_gen[i] - m.mean_pnnl_gen) ** 2 for i in m.idx ) / (len(m.pnnl_gen) - 1)) ** 0.5

    m.stdev_model = (sum((m.hydropower_estimate[i] - m.mean_model) ** 2 for i in m.idx) / 
                   (len(m.hydropower_estimate) - 1)) ** 0.5

    m.mean_obs = m.mean_pnnl_gen

    m.mean_model = sum(m.hydropower_estimate[i] for i in m.idx)/len(m.hydropower_estimate)

    m.kge_constr = Constraint(expr=m.kge ==
                              1 - (((m.corr_coeff - 1) ** 2) + (((m.stdev_model / m.stdev_obs) - 1) ** 2) + 
                                   (((m.mean_model / m.mean_obs) - 1) ** 2)) ** 0.5)        
    
    # ----------------------------
    # ----------------------------
    
    def kge_obj(m):
        return m.kge
        
    def nse_obj(m):
        return m.nse
    
    def combined_obj(m):
        return m.nse + m.kge

    m.obj = Objective(rule=combined_obj, sense=-1)

    return m, adj_df





def solve_model(scenario_name, df_hist, eia, m, print_it=True):
    
    df_test = df_hist[df_hist.EIA_ID == eia]
    df_test['Storage'] = df_test["Storage (m3)"]
    df_test = df_test.reset_index()
    #df_test = df_test[((df_test.month >=4) & (df_test.month <=9))]
    
    
    solver = "ipopt" #get_solver()
    model_solver = SolverFactory("ipopt")
    results = model_solver.solve(m) #, tee=False)

    #print('constants:', m.a(), m.b(), m.c(), m.d(), m.e(), m.f(), m.z()) 

    
    r = [hydropower_estimate() for _, hydropower_estimate in m.hydropower_estimate.items()]
    
    #print(len(r))
    #print(len(df_test))
    
    print('----------', scenario_name, eia, '----------')
    
    print('original NSE =', nse(df_test.WBM_MWh, df_test.pnnl_gen))
    print(f'estimated NSE = {m.nse()}')
    
    print('original peason', scipy.stats.pearsonr(df_test.WBM_MWh, df_test.pnnl_gen)[0])
    print('estimated pearson', scipy.stats.pearsonr(r, df_test.pnnl_gen)[0])
    
    print(f'KGE =  {m.kge()}')
    
    df_test[scenario_name] = r
    df_test['x'] = df_test.index + 1 
    df_test['o_nse'] = nse(df_test.WBM_MWh, df_test.pnnl_gen)
    df_test['o_pearson'] = scipy.stats.pearsonr(df_test.WBM_MWh, df_test.pnnl_gen)[0]
    df_test[('nse_%s' % scenario_name)] = m.nse()
    df_test[('pearson_%s' % scenario_name)] = scipy.stats.pearsonr(r, df_test.pnnl_gen)[0]
    df_test[('kge_%s' % scenario_name)] = m.kge()
    df_test['model_solution'] = results.solver.termination_condition.swapcase()
    
    df_test['t1_a'] = m.a()
    df_test['t1_b'] = m.b()
    df_test['t1_c'] = m.c()
    df_test['t1_d'] = m.d()
    df_test['t1_e'] = m.e()
    df_test['t1_f'] = m.f()
    df_test['t1_z'] = m.z()
    
    #print(len(r))
    #print(len(df_test))
#     if df_test.CH_CW.max()/31 > 500:
#         fig1 = px.line(df_test, x=df_test.x, y=['pnnl_gen', ('%s' % scenario_name)])
#         #Show plot 
#         fig1.show()
    
    print('--------------------')

    return results, df_test






#for scenario_name in scenarios:
def run_hydropower_params(scenario_name):
    
    #df_final_gcms = pd.DataFrame()
    
    df_final = pd.DataFrame()
    adj_df_final = pd.DataFrame()
    print('----------------------------', scenario_name, '----------------------------')
    
    df_hist = import_inputs(scenario_name)
    i = 0
    df_final = pd.DataFrame()
    for eia in df_hist.EIA_ID.unique()[0:len(df_hist.EIA_ID.unique())]: #[:10]:

        m, adj_df = build_hydro_model(scenario_name, df_hist, eia, initial = True)
        results, df_test = solve_model(scenario_name, df_hist, eia, m)
        print(f'MODEL SOLVE = {results.solver.termination_condition.swapcase()}\n')
        
        df_final = pd.concat([df_final, df_test], axis=0, ignore_index=True)
        adj_df_final = pd.concat([adj_df_final, adj_df], axis=0, ignore_index=True)
        i = i + 1
        
#     if len (df_final_gcms) < 1:
#         df_final_gcms = df_final.copy(deep=True)
#     else:
        
#         df_final_gcms[scenario_name] = np.array(df_final[scenario_name])
#         df_final_gcms[('nse_%s' % scenario_name)] = np.array(df_final[('nse_%s' % scenario_name)])
#         df_final_gcms[('pearson_%s' % scenario_name)] = np.array(df_final[('pearson_%s' % scenario_name)])
#         df_final_gcms[('kge_%s' % scenario_name)] = np.array(df_final[('kge_%s' % scenario_name)])
        
    df_final.to_csv("final_combined_%s_nonlinear10.csv" % scenario_name)
    adj_df_final.to_csv("adj_df_final_combined_%s_nonlinear10.csv" % scenario_name)
    
    print("COMPLETE:", scenario_name)
    
    return df_final #, df_final_gcms

